package com.example.investor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
