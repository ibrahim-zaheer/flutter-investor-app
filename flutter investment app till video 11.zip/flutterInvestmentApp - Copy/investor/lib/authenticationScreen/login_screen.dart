import 'package:flutter/material.dart';
import 'package:investor/authenticationScreen/registration_screen.dart';
import 'package:investor/widgets/custom_text_field_widget.dart';
import 'package:get/get.dart';
// import 'registration_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController emailtextEditingController = TextEditingController();
  TextEditingController passwordtextEditingController = TextEditingController();
  bool showProgressBar = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(children: [
            const SizedBox(
              height: 200,
            ),
            Image.asset(
              "images/logo.jpg",
              width: 200,
              height: 200,
            ),
            const Text(
              "Welcome",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 50,
            ),
            const Text(
              "Please Login to find your best solution for making money",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 50,
            ),
            //email

            SizedBox(
              width: MediaQuery.of(context).size.width - 36,
              height: 55,
              child: CustomerTextFieldWidget(
                editingController: emailtextEditingController,
                labeltext: "Email",
                iconData: Icons.email_outlined,
                isObscure: false,
              ),
            ),
            const SizedBox(
              height: 50,
            ),

            //password
            SizedBox(
              width: MediaQuery.of(context).size.width - 36,
              height: 55,
              child: CustomerTextFieldWidget(
                editingController: emailtextEditingController,
                labeltext: "Password",
                iconData: Icons.local_atm_outlined,
                isObscure: true,
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            //button
            Container(
              width: MediaQuery.of(context).size.width - 36,
              height: 50,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(
                  Radius.circular(12),
                ),
              ),
              child: InkWell(
                onTap: () {},
                child: const Center(
                  child: Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            // don't have an account yet page or opening page

            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     Text(
            //       "my poor friend you don't have an account ? ",
            //       style: TextStyle(
            //         fontSize: 20,
            //         color: Colors.grey,
            //         fontWeight: FontWeight.bold,
            //       ),
            //     ),
            //     Builder(
            //       builder: (BuildContext context) {
            //         return InkWell(
            //           onTap: () {
            //             Get.to(
            //               RegistrationScreen(),
            //             );
            //           },
            //           child: const Text(
            //             "Create Here",
            //             style: TextStyle(
            //               fontSize: 20,
            //               color: Colors.white,
            //               fontWeight: FontWeight.bold,
            //             ),
            //           ),
            //         );
            //       },
            //     ),
            //   ],
            // ),

            Row(
              children: [
                Text(
                  "my poor friend you don't have an account ? ",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return RegistrationScreen();
                      }),
                    );
                  },
                  child: const Text(
                    "Create Here",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 50,
            ),
            showProgressBar == true
                ? const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                  )
                : Container(),
            const SizedBox(
              height: 50,
            ),
          ]),
        ),
      ),
    );
  }
}
