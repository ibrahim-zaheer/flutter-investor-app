import 'dart:io';

import 'package:flutter/material.dart';
import 'package:investor/authenticationScreen/login_screen.dart';
import 'package:investor/controllers/authentication_controller.dart';
import '../widgets/custom_text_field_widget.dart';

class RegistrationScreen extends StatefulWidget {
  // const RegistrationScreen({Key? key}) : super(key: key);
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  //personal info
  TextEditingController emailtextEditingController = TextEditingController();
  TextEditingController passwordtextEditingController = TextEditingController();
  TextEditingController nametextEditingController = TextEditingController();
  TextEditingController agetextEditingController = TextEditingController();
  TextEditingController phonetextEditingController = TextEditingController();
  TextEditingController citytextEditingController = TextEditingController();
  TextEditingController CountrytextEditingController = TextEditingController();
  TextEditingController profileHeadingtextEditingController =
      TextEditingController();

  //Professional Information

  TextEditingController OccupationtextEditingController =
      TextEditingController();
  TextEditingController CompanyNametextEditingController =
      TextEditingController();
  TextEditingController jobTitletextEditingController = TextEditingController();
  TextEditingController linkedlntextEditingController = TextEditingController();

  //Investment Experience
  TextEditingController InvestmentExperienceTextEditingController =
      TextEditingController();
  TextEditingController InvestmentPreferencesTextEditingController =
      TextEditingController();
  TextEditingController InvestmentGoalsTextEditingController =
      TextEditingController();

  //financial Information
  TextEditingController NetWorthTextEditingController = TextEditingController();
  TextEditingController AnnualIncomeTextEditingController =
      TextEditingController();
  TextEditingController InvestmentBudgetTextEditingController =
      TextEditingController();

//investment history
  TextEditingController PreviousInvestmentsTextEditingController =
      TextEditingController();
  TextEditingController NotableInvestmentsTextEditingController =
      TextEditingController();

  bool showProgressBar = false;

  var authenticationController = AuthenticationController.authController;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
          child: Center(
        child: Column(children: [
          const SizedBox(
            height: 100,
          ),
          const Text(
            "Create Account",
            style: TextStyle(
              fontSize: 22,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const Text(
            "Basic Information",
            style: TextStyle(
              fontSize: 50,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //choose your image to show it to others
          authenticationController.imageFile == null
              ? const CircleAvatar(
                  radius: 80,
                  backgroundImage: AssetImage("images/avatar_image.jpg"),
                  backgroundColor: Colors.black,
                )
              : Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.blue,
                    image: DecorationImage(
                        fit: BoxFit.fitHeight,
                        image: FileImage(
                          File(
                            authenticationController.imageFile!.path,
                          ),
                        )),
                  ),
                ),
          // const SizedBox(
          //   height: 30,
          // ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                  onPressed: () async {
                    await authenticationController.pickImageFileFromGallery();
                    setState(() {
                      authenticationController.imageFile;
                    });
                  },
                  icon: const Icon(
                    Icons.image_outlined,
                    color: Colors.green,
                  )),
              const SizedBox(
                height: 30,
              ),
              IconButton(
                  onPressed: () async {
                    await authenticationController.captureImageFileFromCamera();
                    setState(() {
                      authenticationController.imageFile;
                    });
                  },
                  icon: const Icon(
                    Icons.camera_alt,
                    color: Colors.green,
                  ))
            ],
          ),

          const SizedBox(
            height: 30,
          ),

          //name

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: nametextEditingController,
              labeltext: "Name",
              iconData: Icons.person_outlined,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          //email

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: emailtextEditingController,
              labeltext: "Email",
              iconData: Icons.email_outlined,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          //password
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: emailtextEditingController,
              labeltext: "Password",
              iconData: Icons.local_atm_outlined,
              isObscure: true,
            ),
          ),

          // const Text(
          //   "Login now to find your best investor or someone to invest in",
          //   style: TextStyle(
          //     fontSize: 10,
          //     color: Colors.grey,
          //     fontWeight: FontWeight.bold,
          //   ),
          // ),

          //age

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: agetextEditingController,
              labeltext: "Age",
              iconData: Icons.email_outlined,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          //phone

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: phonetextEditingController,
              labeltext: "Phone",
              iconData: Icons.phone,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          //city

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: citytextEditingController,
              labeltext: "City",
              iconData: Icons.location_city,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          //country

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: CountrytextEditingController,
              labeltext: "Country",
              iconData: Icons.location_city,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          //profileHeading

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: profileHeadingtextEditingController,
              labeltext: "profileHeading",
              iconData: Icons.text_fields,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

          const SizedBox(
            height: 50,
          ),

          //Professioal Info
          const Text(
            "Profeesional Information",
            style: TextStyle(
              fontSize: 50,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //occupation
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: OccupationtextEditingController,
              labeltext: "Occupation",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          //Company Name
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: CompanyNametextEditingController,
              labeltext:
                  "Company Name(in case of self employed write self employed)",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Job Tile
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: jobTitletextEditingController,
              labeltext:
                  "Job Title(in case of self employeed write same as occupation)",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          //linkedln

          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: linkedlntextEditingController,
              labeltext: "Linkedln Profile",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment Experience

          const Text(
            "Investment Experience",
            style: TextStyle(
              fontSize: 50,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment Experience
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: InvestmentExperienceTextEditingController,
              labeltext: "Investment Experience",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          //Investment Preference
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: InvestmentPreferencesTextEditingController,
              labeltext: "Investment Preferences",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment Goals
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: InvestmentGoalsTextEditingController,
              labeltext: "Investment Goals",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

//Financial Information

          const Text(
            "Financial Information",
            style: TextStyle(
              fontSize: 50,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment Budget
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: InvestmentBudgetTextEditingController,
              labeltext: "Investment Budget",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          //networth
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: NetWorthTextEditingController,
              labeltext: "NetWorth",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Annual Income
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: AnnualIncomeTextEditingController,
              labeltext: "Annual Income",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

//Investment History

          const Text(
            "Investment History",
            style: TextStyle(
              fontSize: 50,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment History
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: PreviousInvestmentsTextEditingController,
              labeltext: "Investment History",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          //Notable Investment
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: NotableInvestmentsTextEditingController,
              labeltext: "Notable Investment",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          //Investment Goals
          SizedBox(
            width: MediaQuery.of(context).size.width - 36,
            height: 55,
            child: CustomerTextFieldWidget(
              editingController: InvestmentGoalsTextEditingController,
              labeltext: "Investment Goals",
              iconData: Icons.person,
              isObscure: false,
            ),
          ),
          const SizedBox(
            height: 30,
          ),

//button
          Container(
            width: MediaQuery.of(context).size.width - 36,
            height: 50,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(
                Radius.circular(12),
              ),
            ),
            child: InkWell(
              onTap: () {},
              child: const Center(
                child: Text(
                  "Login",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 50,
          ),
          // don't have an account yet page or opening page

          // Row(
          //   mainAxisAlignment: MainAxisAlignment.center,
          //   children: [
          //     Text(
          //       "my poor friend you don't have an account ? ",
          //       style: TextStyle(
          //         fontSize: 20,
          //         color: Colors.grey,
          //         fontWeight: FontWeight.bold,
          //       ),
          //     ),
          //     Builder(
          //       builder: (BuildContext context) {
          //         return InkWell(
          //           onTap: () {
          //             Get.to(
          //               RegistrationScreen(),
          //             );
          //           },
          //           child: const Text(
          //             "Create Here",
          //             style: TextStyle(
          //               fontSize: 20,
          //               color: Colors.white,
          //               fontWeight: FontWeight.bold,
          //             ),
          //           ),
          //         );
          //       },
          //     ),
          //   ],
          // ),

          Row(
            children: [
              Text(
                "my rich friend now click on this button and make all your dreams come true",
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (BuildContext context) {
                      return LoginScreen();
                    }),
                  );
                },
                child: const Text(
                  "Create Here",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 50,
          ),

//if already have an account click here

          Row(
            children: [
              Text(
                "Already Have an Account",
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (BuildContext context) {
                      return LoginScreen();
                    }),
                  );
                },
                child: const Text(
                  "Click Here",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 50,
          ),

          showProgressBar == true
              ? const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                )
              : Container(),
          const SizedBox(
            height: 50,
          ),
        ]),
      )),
    );
  }
}
