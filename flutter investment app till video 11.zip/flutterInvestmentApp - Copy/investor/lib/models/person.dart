import 'package:cloud_firestore/cloud_firestore.dart';

class Person {
  //personal infro
  String? ImageProfile;
  String? name;
  String? age;
  String? email;
  String? password;
  String? phone;
  String? city;
  String? country;
  int? publishedDateTime;
  //Professional Information
  String? occupation;
  String? companyName;
  String? jobTitle;
  String? linkedln;

  //Investment Experience

  String? InvestmentEperience;
  String? InvestmentPreference;
  String? InvestmentGoal;
  //financial Information
  String? netWorth;
  String? annualIncome;
  String? InvestmentBudget;

  //investment history
  String? previousInvestment;
  String? NotableInvestment;
  Person(
      {this.ImageProfile,
      this.name,
      this.age,
      this.email,
      this.password,
      this.phone,
      this.city,
      this.country,
      this.publishedDateTime,

//Professional Information
      this.occupation,
      this.companyName,
      this.jobTitle,
      this.linkedln,

      //Investment Experience

      this.InvestmentEperience,
      this.InvestmentPreference,
      this.InvestmentGoal,
      //financial Information
      this.netWorth,
      this.annualIncome,
      this.InvestmentBudget,

      //investment history
      this.previousInvestment,
      this.NotableInvestment});

  //for retrieving data from json
  static Person fromDataSnapshot(DocumentSnapshot snapshot) {
    var dataSnapshot = snapshot.data() as Map<String, dynamic>;
    return Person(
      name: dataSnapshot['name'],
      ImageProfile: dataSnapshot['ImageProfile'],
      age: dataSnapshot['age'],
      email: dataSnapshot['email'],
      password: dataSnapshot['password'],
      phone: dataSnapshot['phone'],
      city: dataSnapshot['city'],
      country: dataSnapshot['country'],
      publishedDateTime: dataSnapshot['publishedDateTime'],
      occupation: dataSnapshot['occupation'],
      companyName: dataSnapshot['companyName'],
      jobTitle: dataSnapshot['jobTitle'],
      linkedln: dataSnapshot['linkedln'],
      InvestmentEperience: dataSnapshot['InvestmentEperience'],
      InvestmentPreference: dataSnapshot['InvestmentPreference'],
      InvestmentGoal: dataSnapshot['InvestmentGoal'],
      netWorth: dataSnapshot['netWorth'],
      annualIncome: dataSnapshot['annualIncome'],
      InvestmentBudget: dataSnapshot['InvestmentBudget'],
      previousInvestment: dataSnapshot['previousInvestment'],
      NotableInvestment: dataSnapshot['NotableInvestment'],
    );
  }

//for saving data to json
  Map<String, dynamic> toJson() => {
        "name": name,
        "ImageProfile": ImageProfile,
        "age": age,
        "email": email,
        "password": password,
        "phone": phone,
        "city": city,
        "country": country,
        "publishedDateTime": publishedDateTime,
        "occupation": occupation,
        "companyName": companyName,
        "jobTitle": jobTitle,
        "linkedln": linkedln,
        "InvestmentEperience": InvestmentEperience,
        "InvestmentPreference": InvestmentPreference,
        "InvestmentGoal": InvestmentGoal
      };
}
