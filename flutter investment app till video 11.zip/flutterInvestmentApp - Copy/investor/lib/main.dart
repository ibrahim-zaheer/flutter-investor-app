import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:investor/authenticationScreen/login_screen.dart';
import 'package:investor/authenticationScreen/registration_screen.dart';
import 'package:investor/controllers/authentication_controller.dart';
import 'package:get/get.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const MyApp());
  await Firebase.initializeApp().then((value) {
    Get.put(AuthenticationController());
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepOrange,
          title: Text('Hello World'),
          centerTitle: true,
        ),
        body: LoginScreen(),
        // body: RegistrationScreen(),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}















// import 'package:flutter/material.dart';
// import 'package:investor/authenticationScreen/login_screen.dart';
// import 'package:investor/authenticationScreen/registration_screen.dart';
// import 'package:investor/controllers/authentication_controller.dart';

// void main() async => runApp(
//   WidgetsFlutterBinding.ensureInitialized();
//   Get.put(AuthenticationController());
//       MaterialApp(
//         theme: ThemeData.dark().copyWith(
//           scaffoldBackgroundColor: Colors.black,
//         ),
    
//         home: Scaffold(
//           appBar: AppBar(
//             backgroundColor: Colors.deepOrange,
//             title: Text('Hello World'),
//             centerTitle: true,
//           ),
//           // always use child property for using widget within a widget
//           body: LoginScreen(),
//           // body: RegistrationScreen(),
//         ),
//         debugShowCheckedModeBanner: false,
//       ),
      
//     );
    














